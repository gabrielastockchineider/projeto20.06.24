const caixaprincipal  = document.querySelector(".caixa-principal");
const caixaperguntas  = document.querySelector(".caixa-perguntas");
const caixaalternativas = document.querySelector(".caixa-alternativas");
const caixaresposta  = document.querySelector(".caixa-resposta");